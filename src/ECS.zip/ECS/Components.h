#ifndef _COMPONENTS_H
#define _COMPONENTS_H

#include "ECS.h"
#include "MenuComponent.h"
#include "ButtomComponent.h"
#include "GameBoardComponent.h"
#include "BackGroundComponent.h"
#include "TextButtomComponent.h"
#include "DoubleGameBoardComponent.h"

#endif